class QuestionOption < ApplicationRecord
  belongs_to :question
end
