ActiveAdmin.register Answer do
  permit_params :answer

end
