ActiveAdmin.register Form do
  permit_params :title
end
